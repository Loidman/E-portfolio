DecisionThree final evaluation package

Open reproduction/DecisionThree_Final_Project_Notebook.ipynb.
It retains the executed Colab model outputs and earlier experiment summaries.
Section 12 adds the reviewed final scores and findings calculated from those outputs.
No model responses, measured timings or historical raw records were changed.

The reviewed Excel workbook and full response-evaluation CSV are in
final_project/deliverables/. The CSV includes all 16 questions, references,
actual answers, stage timings, scores, reasons and exact source locations.
The workbook also contains the earlier notebook-generated benchmark tables.
These values originate in notebook execution; the ZIP is their transport package.

Final run: 20261110T085803_ec00489c. Tesla T4 GPU. Revised prompt, Qwen2.5-1.5B,
D = 800 characters / 200 overlap / top_k 3. One excluded warm-up and one fresh
response to each of 16 questions. Mean response: 3.58038184562502 seconds.
Answerable success: 6/12. Unanswerable handling success: 1/4. Overall: 7/16.
The fixed rubric defines success separately for these two classes.

reviews/Final_Project_Response_Review.json binds each judgment to its actual
question, answer, full prompt and ordered passages. This review used AI
assistance and does not claim new group verification. The original 12 responses
and their context exactly match the previously audited development run.
The 16-question set is not wholly unseen because Q01-Q12 were used earlier.

Reproduction in Colab: select a GPU runtime, run Section 1, restart the session,
then run Section 2 onward. In Section 3 upload this package or the original
DecisionThree_Final_Project_Input.zip. Only inputs/source is indexed. References
and review files are evaluation material, not retrieval documents.
Section 11 generates new answers. Section 12 applies an existing review only if
the answer, prompt and passages match exactly. New outputs require new review.
Setup and model loading are separate from response timings.

Original unreviewed response tables and the pre-review executed notebook are
retained under reviews/original and reproduction/original. Older prototype
notebooks are retained as provenance; use the notebook named above.

This package covers experiment and evaluation evidence. The final report,
member responsibility matrix and signed integrity/AI-use statement are separate
course deliverables and are not represented as complete by this package.
