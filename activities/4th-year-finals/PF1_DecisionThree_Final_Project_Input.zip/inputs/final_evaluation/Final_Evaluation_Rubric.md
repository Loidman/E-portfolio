# Final 16-question evaluation rubric

We evaluate Q01-Q12 as answerable and Q13-Q16 as unanswerable from the supplied CSE-only knowledge base. The source edition is SY 2026-2027. Unanswerable does not mean that the answer is unavailable from every JRU source.

## Answerable questions: Q01-Q12

We retain the original fixed rubric, reference facts, grouped prerequisite/code-list elements, and source-page references. Correctness and source support are separate 0-2 ratings; completeness is the correctly answered required-element fraction. A correct incomplete answer may receive correctness 2 while having completeness below 1. A fact can be correct in the handbook but unsupported by the model's actual passages. We inspect any explicit citation against its named passage; a wrong source attribution prevents full source support.

## Unanswerable questions: Q13-Q16

We expect the chatbot to state that the specific requested detail is not available in the supplied documents. It may give brief related facts or suggest checking an official applicable source, but those additions must not invent the missing answer or a contact/URL.

Correctness: 2 means a clear, correct acknowledgement of the missing detail with no invented requested value. 1 means an ambiguous or partly correct acknowledgement with a misleading/unverifiable extra claim. 0 means it gives an unsupported requested answer, says the detail is documented when it is not, or otherwise fails to identify the information gap.

Source support: 2 means the information-gap statement is appropriate to the supplied context and any added factual claims are supported. 1 means some claims are supported and others are unsupported or attached to another course/program. 0 means it supplies the requested unsupported fact without a supported substantive response. A proper acknowledgement of missing information is not penalized for having no positive source passage that states the absent fact.

Completeness uses two response requirements for each unsupported question: U1 identifies that the requested detail is not supplied; U2 avoids inventing or borrowing the requested value. The score is the number met divided by 2. U2 alone can be met by a vague non-answer, but that does not establish correct or complete handling of the question. We also record the response decision (answer, abstain, or partial) and whether unsupported requested details appear. We do not grade by matching a refusal keyword or copying the reference wording.

## Retrieval and comparisons

For Q01-Q12 we can retain Precision@K and documentary coverage under the original definitions. For Q13-Q16, a course description can be topically relevant without containing the requested fact. We label this topical relevance separately. Documentary answer coverage is N/A for these questions; there are no positive documentary units to use as its denominator. We do not report 0/0 or pretend topical similarity proves answerability.

We show answerable and unanswerable results separately. Fully successful answerable questions require correctness 2, support 2, and completeness 1. Successful handling of unsupported questions requires a specific information-gap acknowledgement and no invented requested detail; it must be checked against the actual response and passages. Overall success, if reported, must name these two class-specific criteria and provide the 12/4 class breakdown.

## Execution and review

We freeze the revised prompt, original PDF, Qwen2.5-1.5B-Instruct, MiniLM embeddings, float32, greedy decoding, seed 42, maximum 256 new tokens, and D=800/200/3 before collecting the new responses. This evaluation uses one warm-up plus one fresh response to each of the 16 questions. It is a quality evaluation, not a replacement for the earlier three-trial CPU/GPU benchmark.

We save actual questions, answers, complete prompts, ranked passages, source locations, token counts, timing stages, and run controls. Reference answers, answerability labels, this rubric, and old reviews are excluded from the retrieval index and generation function's question/context inputs. No new quality score is prefilled from the old run. The review CSV is ungraded until its actual responses and evidence have been checked. Repeated or resumed runs are not additional independent question samples.

The original 12 questions were already inspected during development; the expanded 16 are not a wholly unseen test set. Q13-Q16 must not be used to rewrite the prompt and then reported as an untouched test of that new prompt. Any later prompt change requires a new identified experiment and suitable separate evaluation questions.
