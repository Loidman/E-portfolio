DecisionThree final project evaluation input package

Open DecisionThree_Final_Project_Evaluation.ipynb in a GPU Colab runtime. Run Sections 1-11 in order. Upload this ZIP in Section 3. Keep the default revised-prompt D configuration. The older benchmark loop is disabled by default; the live pipeline and new Section 11 evaluation still run.

inputs/source: the unchanged CSE-only source PDF.
inputs/evaluation: unchanged original 12-question benchmark key and rubric.
inputs/final_evaluation: the new 16-question set, reference answers, rubric, readable questions, and checks explaining why Q13-Q16 are absent from this source.
experiments, reviews, tables, supplementary: actual earlier benchmark evidence and its source audit. These are historical records, not fresh 16-question outputs.
preprocessed: the earlier prepared-source strategy and reproduction files; the selected final evaluation uses the original PDF.
reproduction: the old supporting notebooks and the new final evaluation notebook.

New final evaluation outputs are saved under final_project/results/<run_id> after execution. No new answers or quality scores are included in this input package. Q01-Q12 remain the same development questions; Q13-Q16 add unsupported requests. Reference answers and labels never enter the knowledge index or answer_question inputs.

Section 11 exports DecisionThree_Final_Project_Evaluation_Results.zip. Save the executed .ipynb separately with visible outputs and provide both files for result checking. The final response-review CSV is intentionally ungraded until the actual answers and evidence are assessed.
