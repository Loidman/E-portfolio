# Final project evaluation: 16 questions

We retain the original 12 questions and reference answers and add four unsupported questions. The expected answers below are evaluation references, not model outputs. No new response has been generated yet.

The knowledge base is the CSE-only General Information SY 2026-2027 PDF. Answerability is judged within that source, including unresolved source conflicts.

## Q01 — answerable

What does the Bachelor of Science in Computer Engineering (BSCpE) program focus on?

Reference / expected behavior: BSCpE covers the design, development, implementation, maintenance and integration of software and hardware components for modern computing systems and computer-controlled equipment.

## Q02 — answerable

What unit values are listed for Computer Architecture and Organization in the BSCpE year-by-year curriculum, group requirements, and CPE C401 course description? Do these listings agree?

Reference / expected behavior: The year-by-year curriculum lists CPE C401 as 4 units, the group-requirements table lists Computer Architecture & Organization as 2 units, and the course description lists 4 credit units. They do not agree (4, 2 and 4). These passages do not establish which listing should be corrected.

## Q03 — answerable

How many lecture units are listed for ECE C405, Design Project 1?

Reference / expected behavior: ECE C405, Design Project 1, lists 1 lecture unit.

## Q04 — answerable

For ECE C401, ECE Elective 1 (Broadcast Production Engineering 1), what prerequisites and lecture, laboratory, and credit units are listed?

Reference / expected behavior: The prerequisites are ECE C306 and ECE C308. The course lists 3 lecture units, 1 laboratory unit and 4 credit units.

## Q05 — answerable

In the Digital Animation Technology curriculum, in which year and semester is EMC C402 Internship listed, and how many units does it carry?

Reference / expected behavior: EMC C402 Internship is listed in the fourth year, second semester, with 9 units.

## Q06 — answerable

For EMC C504 Advanced 2D Animation, what prerequisites and lecture, laboratory, and credit units are listed?

Reference / expected behavior: The prerequisites are EMC C203 and EMC C501. Advanced 2D Animation lists 2 lecture units, 1 laboratory unit and 3 credit units.

## Q07 — answerable

What prerequisite is listed for EMC C614 Multi-Player and Network Games?

Reference / expected behavior: The listed prerequisite is EMC C603.

## Q08 — answerable

What are the complete prerequisite lists for Game Programming 1, 2, and 3 (EMC C602, EMC C603, and EMC C604)? Does passing Game Programming 1 alone satisfy the listed prerequisites for Game Programming 2?

Reference / expected behavior: Game Programming 1 (EMC C602) requires EMC C201, EMC C203 and EMC C601. Game Programming 2 (EMC C603) requires EMC C602 and EMC C608. Game Programming 3 (EMC C604) requires EMC C603. Passing Game Programming 1 alone does not satisfy the full listed prerequisite set for Game Programming 2 because EMC C608 is also listed.

## Q09 — answerable

What prerequisites and credit units are listed in the course description for ITC C402 Internship?

Reference / expected behavior: ITC C402 Internship lists ITC C508 and ITC C403 as prerequisites and carries 6 credit units.

## Q10 — answerable

Compare the course codes and total units listed for the fourth-year first semester of BSIT and BSIT with specialization in Business Analytics.

Reference / expected behavior: BSIT lists ITC C401, ITC C403, EMC C307 and ITC C508, for a total of 12 units. BSIT with specialization in Business Analytics lists ITC C206, ITC C401, ITC C403, ITC C611 and ITC C612, for a total of 15 units. Each listed first-semester course carries 3 units.

## Q11 — answerable

According to the BSIT Business Analytics program description, which three data competencies does the specialization develop, and what two business purposes can that knowledge serve?

Reference / expected behavior: The specialization develops understanding of data structures, data analysis and data interpretation. The knowledge can support operational optimization and competitive advantage.

## Q12 — answerable

How do ITC C604 Data Analysis using Excel and ITC C605 Data Management and Statistical Analysis using R differ in their listed prerequisites and credit units?

Reference / expected behavior: ITC C604 requires ITC C601 and ITC C603 and carries 3 credit units. ITC C605 requires ITC C604, ITC C602 and ITC C201 and also carries 3 credit units. Their prerequisite sets differ, while their credit units are the same.

## Q13 — unanswerable

How many on-the-job training hours must a BSIT student complete for ITC C402 Internship?

Reference / expected behavior: The supplied CSE documents do not state the required training hours for BSIT ITC C402 Internship. They list 6 credit units, but units cannot be converted into a required hour count from this source. Hours stated for other programs must not be transferred to BSIT.

Why unsupported: The complete ITC C402 description and both IT curriculum occurrences specify units/prerequisites, not internship hours. The source-wide hour/hrs occurrences belong to other programs.

## Q14 — unanswerable

Which version of Microsoft Excel is required for ITC C604 Data Analysis using Excel?

Reference / expected behavior: The supplied documents identify Excel as the tool used in ITC C604, but do not specify a required Excel version. A version such as Excel 2019, Excel 2021, or Microsoft 365 cannot be confirmed from this source.

Why unsupported: The entire cross-page ITC C604 description names Excel but no release/version. Other Excel/VBA occurrences do not establish a required version for C604.

## Q15 — unanswerable

What is the exact total tuition and mandatory fees for a first-year BSIT student in the first semester of SY 2026-2027?

Reference / expected behavior: The supplied CSE program and curriculum documents do not contain the tuition and mandatory fee amounts needed to calculate an exact total. The amount cannot be confirmed from this knowledge base; it requires an official applicable fee assessment.

Why unsupported: The filtered source contains no tuition or fee schedule. Whole-word searches for tuition and fee/fees return zero; the document scope is CSE programs, curricula, and course descriptions.

## Q16 — unanswerable

On which days and at what times is ITC C605 Data Management and Statistical Analysis using R scheduled in SY 2026-2027?

Reference / expected behavior: The supplied documents describe ITC C605 but do not provide its class meeting days or times. Its timetable cannot be confirmed from the curriculum or course description; an official class schedule is needed.

Why unsupported: The complete ITC C605 entry has content, units, and prerequisites but no meeting timetable. No weekday names occur in the readable filtered source; the schedule occurrence concerns project management, not a class schedule.
