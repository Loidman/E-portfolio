DecisionThree RAG experiment data and notebook input package.

Measurements are the actual saved notebook outputs from the completed experiments.
We use the exported records to reproduce the notebook tables and trace each measurement to its experiment and trial.

inputs/source: unchanged CSE-only General Information SY 2026-2027 PDF.
inputs/evaluation: fixed 12 questions, reference key, rubric, readable questions, source/page maps and pinned model revisions. These are not indexed as knowledge.
inputs/experiment_protocols.json: actual recorded controls for each experiment.
experiments/main/results: original-prompt Qwen2.5-1.5B CPU A/B/C and GPU A/B/C/D/E; trial 0 warm-up, trials 1-3 measured.
experiments/prompt/results: revised-prompt D GPU follow-up, original PDF unchanged.
experiments/sourceprep/results: revised-prompt D GPU with prepared source records.
preprocessed: exact structured records, readable source, curriculum CSVs, manifest and the PDF-only reproduction script.
reviews: source-based semantic judgments and their notes, bound to exact saved question/answer/prompt/evidence signatures. The group verified the initial scores. Current scores include the later source-audit correction described in reviews/Final_Source_Audit_README.txt. Original pre-verification reviews are retained under reviews/original as historical records; repeated identical answers are not independent reviews.
supplementary/qwen3_nf4: separate Qwen3-8B NF4 GPU experiments and interrupted CPU pilots. There are no completed CPU answer measurements for that model and no valid Qwen3 CPU/GPU speedup.
supplementary/source_provenance: original unfiltered General Information PDF and original CSE-filtering script/notes. These document the filtered source's origin; they are never indexed by the final notebook. The filtering script retains its original workspace path settings; the ready-to-run filtered PDF is already supplied under inputs/source.
reproduction: the final consolidated notebook with its retained model-execution outputs and recalculated source-audit tables.
reproduction/completed_runs: the three earlier executed notebooks with group-voice explanations. Their original code cells and actual output logs are preserved as supporting experiment evidence. The final submission notebook is the consolidated one saved separately after running it.
tables: created by the notebook from raw records after execution; warm-ups and incomplete trials are not included in measured means.

Use DecisionThree_RAG_Experiment_Notebook.ipynb in Colab. Sections 1-9 follow the supplied template's live pipeline: install, configure, upload, load/split, vector database, model, RAG function, testing/measurements, optional chat. Upload this package in Section 3. The default runs revised-prompt D on an actual GPU, including a real diagnostic answer, warm-up and three fresh measured trials. Section 10 consolidates all experiments and exports. Set EXPERIMENT="main" and the actual CPU/GPU device to reproduce the original matrix. REMEASURE_COMPLETE=True preserves previous selected trials under a history folder before collecting fresh measurements; False resumes missing trials while retaining completed ones.

CPU/GPU speedups use matching source/model/prompt/settings/chunks only. Follow-up GPU times are never combined with old main-experiment CPU times. The main CPU host and GPU-session host differ; Colab sessions/hardware vary.

Archived findings before the fresh final run: revised-prompt/raw-PDF D was the best tested GPU follow-up under the stated rubric, with 6/12 fully correct/complete/supported answers. Original-prompt D and source-prepared D each had 5/12. Newly generated answers need matching source-based judgments before updating that conclusion. This does not establish generalization or reliability for academic advising. The same development questions were used to design the follow-ups.

Final deliverables: DecisionThree_RAG_Experiment_Notebook.ipynb (save executed notebook separately), DecisionThree_RAG_Experiment_Results.xlsx, DecisionThree_RAG_Experiment_Report.pdf, DecisionThree_RAG_Experiment_Data.zip. The Excel workbook and report use the checked results of this consolidated execution.

GROUP VERIFICATION
The group confirmed verification of the existing answer-quality scores after measurement. Current bound ratings and consolidated notebook labels also reflect the subsequent source audit and its separately identified correction. Earlier review files and supporting notebook outputs describe their original state and remain as history. New unmatched model answers still require review.

FINAL SOURCE AUDIT
The final source audit checked all 84 unique answer/context cases and corrected original C Q03 source support from 2 to 1 for a wrong Source 2 citation. Current scores and summaries reflect this correction. The group’s earlier verification and the later audit are recorded separately. All raw model answers, prompts, retrieved passages, and timings are unchanged. See reviews/Final_Source_Audit_README.txt and reviews/Final_Source_Audit.json.
