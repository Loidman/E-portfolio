JRU CSE source dataset for WW1-WW2 Optimization and GPU Testing

SOURCE
COL-GI-2026-2027.pdf: 280 pages. The original cover visibly states
General Information, School Year 2026-2027, College Division.
Original SHA-256: d43a51e867310101d54061126364167259eb319d68e5f8ae791926d84a151a90

FILTERED FILE
COL-GI-2026-2027_CSE_Only.pdf: 64 pages, including the original cover.
There are 63 pages with text for retrieval. The image-only cover documents
edition/provenance and should not be embedded as an empty document.

SELECTION (1-based page numbers)
Filtered page 1: original PDF page 1, edition cover.
Filtered page 2: original PDF page 9, printed page 7. Only the CSE dean,
four relevant department chairpersons, and shared directory headings remain.
Filtered pages 3-27: original PDF pages 75-99, printed pages 73-97.
These cover the CSE mission/vision, program descriptions, objectives,
outcomes, curricula, group requirements and program-specific conditions.
Filtered pages 28-64: original PDF pages 186-222, printed pages 184-220.
These cover Computer Engineering, Electronics Engineering, Information
Technology, and Entertainment and Multimedia Computing course descriptions.

PROGRAM COVERAGE
BSCpE; BSEcE; BSEMC Digital Animation Technology; BSEMC Game Development;
BSIT; and BSIT with specialization in Business Analytics.
No separate Computer Science program has been added or inferred.

BOUNDARY EDITS
Original page 9: unrelated leadership and department entries removed.
Original page 99: only the BSIT-BA group-requirements continuation retained.
Original page 186: preceding criminology Research 1/2 content removed.
Original page 222: only the final EMC C614 description retained.
Removal is permanent PDF-content removal, not just a display crop.
Remaining text and course facts are unchanged. Blank areas preserve source layout.

SCOPE
This follows the proposal's CSE program/curriculum subject scope using the
2026-2027 edition selected for this activity. The earlier proposal mentioned
2025-2026; this experiment uses the selected 2026-2027 edition.
Unrelated colleges, general university administration, broad faculty biographies,
fees, admissions processing and other university-wide sections are excluded.
Common/general-education subjects listed inside CSE curricula remain in context.
The leadership excerpt is auxiliary college information, not a faculty-availability list.
Source conflicts and awkward source wording are retained, not silently corrected.

PAGE REFERENCES
CSE_Page_Map.csv maps every filtered PDF page to its original PDF page,
printed page, selection description and retrieval inclusion flag.
Use all three page identifiers in notebook metadata and evaluation evidence.
The filtered PDF page number is not the original PDF or printed page number.

REPRODUCTION
create_cse_dataset.py requires Python and PyMuPDF (fitz).
Run: python create_cse_dataset.py COL-GI-2026-2027.pdf output_folder
The script verifies the original source hash before filtering.
CSE_Source_Manifest.json records source/filtered hashes and the page mapping.
The original PDF is included in this source package so filtering can be repeated.

NEXT STAGE
Use only the filtered PDF as the retrieval source. Do not index the original
handbook again, this README, the mapping files, or future question/answer keys.
Prepare and verify questions across the six program/specialization tracks,
then use identical sources and questions throughout CPU/GPU experiments.
These notes describe the original source-filtering stage. The final experimental data, measurements, and evaluation records are supplied in the enclosing DecisionThree_RAG_Experiment_Data.zip.
