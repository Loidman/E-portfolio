"""Create the CSE-only source dataset from the supplied 2026-2027 handbook.
Usage: python create_cse_dataset.py COL-GI-2026-2027.pdf OUTPUT_DIRECTORY
Requires PyMuPDF (import fitz). No text is rewritten or inferred.
"""
from pathlib import Path
import csv,hashlib,json,sys
import fitz

def build(source,destination):
 source=Path(source);destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
 assert hashlib.sha256(source.read_bytes()).hexdigest() == 'd43a51e867310101d54061126364167259eb319d68e5f8ae791926d84a151a90', 'The source differs from the verified 2026-2027 handbook.'
 doc=fitz.open(source);out=fitz.open();records=[]
 selected=[1,9]+list(range(75,100))+list(range(186,223))
 assert len(doc)==280, 'Expected the supplied 280-page handbook.'
 for original in selected:
  out.insert_pdf(doc,from_page=original-1,to_page=original-1)
  page=out[-1];selection='Full page';kind='CSE course descriptions'
  if original==1:kind='Edition cover (provenance only)'
  elif original==9:
   kind='CSE dean and department chairpersons';selection='CSE entries and shared directory headings only'
   # Keep source rows in their original positions; permanently remove all other entries.
   bands=[(0,86),(121,148),(327,342),(359,373),(412,439),(465,479)]
   y=0
   for lo,hi in bands:
    if lo>y:page.add_redact_annot(fitz.Rect(0,y,page.rect.width,lo),fill=(1,1,1))
    y=hi
   page.add_redact_annot(fitz.Rect(0,y,page.rect.width,page.rect.height),fill=(1,1,1));page.apply_redactions()
  elif 75<=original<=99:
   kind='CSE mission, programs, curricula and requirements'
   if original==99:
    selection='BSIT-BA group-requirements continuation only'
    cut=page.search_for('COLLEGE OF EDUCATION, ARTS, AND SCIENCES')[0].y0-2
    page.add_redact_annot(fitz.Rect(0,cut,page.rect.width,page.rect.height),fill=(1,1,1));page.apply_redactions()
  if original==186:
   selection='CSE course-description section from its heading onward; preceding criminology research courses removed'
   cut=page.search_for('COMPUTER STUDIES AND ENGINEERING')[0].y0-2
   page.add_redact_annot(fitz.Rect(0,55,page.rect.width,cut),fill=(1,1,1));page.apply_redactions()
  if original==222:
   selection='EMC C614 course description only; following Education section removed'
   cut=page.search_for('EDUCATION, ARTS, AND SCIENCES')[0].y0-2
   page.add_redact_annot(fitz.Rect(0,cut,page.rect.width,page.rect.height),fill=(1,1,1));page.apply_redactions()
  records.append({'filtered_pdf_page':len(out),'original_pdf_page':original,'printed_page':'' if original==1 else original-2,'section':kind,'selection':selection,'include_in_retrieval':original!=1})
 out.set_metadata({'title':'JRU College General Information SY 2026-2027 — CSE-only excerpt','subject':'CSE program and curriculum RAG source dataset; filtered from COL-GI-2026-2027.pdf','author':'Jose Rizal University','keywords':'CSE, 2026-2027, BSCpE, BSEcE, BSEMC, BSIT, BSIT-BA'})
 out.set_toc([[1,'Original edition cover (not indexed)',1],[1,'CSE leadership (selected source entries)',2],[1,'CSE mission, programs and curricula',3],[1,'CSE course descriptions',28]])
 target=destination/'COL-GI-2026-2027_CSE_Only.pdf';out.save(target,garbage=4,deflate=True);out.close();doc.close()
 with (destination/'CSE_Page_Map.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
 manifest={'source_file':source.name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_pages':280,'edition':'SY 2026-2027 (verified visually on original cover)','filtered_file':target.name,'filtered_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'filtered_pages':64,'retrieval_pages':63,'filtering_policy':'Only CSE program/curriculum sections, CSE leadership entries and original edition cover. Boundary-page content from other colleges is permanently removed, not just hidden by cropping. No source fact or course wording is corrected.','pages':records}
 (destination/'CSE_Source_Manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
 return target,records

if __name__=='__main__':
 target,rows=build(sys.argv[1],sys.argv[2]);print(target);print('Filtered pages:',len(rows))
