# CSE source preparation, version 1

This dataset is a structured representation of the unchanged CSE-only General Information PDF, SY 2026–2027. The PDF remains the authoritative source. This preparation changes representation and document boundaries; it does not add answers or correct the handbook.

## Files

- `CSE_Structured_Records.jsonl`: the searchable input when the sourceprep experiment is selected. Every line is a record with an ID, text, kind, and filtered PDF page references. Course entries contain exact pypdf page spans; table rows contain physical bounding boxes or the semester's source-row coordinates.
- `CSE_Structured_Source.txt`: the same records in a readable text format for inspection.
- `Curriculum_Rows.csv`: all 341 curriculum course rows with program/year/semester and printed units.
- `Semester_Totals.csv`: all 51 semester/summer summaries, preserving printed totals alongside computed row sums.
- `Preprocessing_Manifest.json`: source and dataset SHA-256 hashes, record counts, preparation method, dependency versions, and unresolved source issues.
- `prepare_cse_source.py`: the reproducible preparation script. It reads only the PDF; no evaluation or model-result file is read.

## Preparation rules

1. Use word positions to separate left First Semester and right Second Semester columns. Carry year/program headings into each derived row. Join wrapped course titles within their own column. Spaced codes such as `PED C 201` become `PED C201`; the original physical row text remains in the semester record.
2. Produce a labeled course row for every course and a code-list/printed-total summary for every semester and summer table. The same rules apply to all six program/track curricula.
3. Preserve group requirements by physical row with the appropriate program/category context. Do not infer course codes from similar course titles. Wrapped or incomplete source rows remain source fragments rather than guessed facts.
4. Detect all printed course-description headings. Assemble each course across page breaks before creating source records. Keep distinct track/program-specific descriptions separate even when their course code repeats.
5. Place each course's verbatim units/prerequisite statement before its full description. The statement is copied, not inferred from total units. Do not attach the preceding course's footer to the next course.
6. Preserve the remaining leadership, program descriptions, objectives, outcomes, elective text, and source headings. The image-only cover contributes no searchable text. Page headers are generally omitted from content; page references remain metadata.
7. Index one record at a time using the existing recursive character splitter. D retains chunk size 800, overlap 200, Top-K 3. Changed record boundaries prevent a chunk from joining different course/semester records. Long descriptions may still split, but their units/prerequisites appear beside their course identity near the beginning.

This is a combined preparation strategy: table unfolding, source grouping, content ordering, and record/page-range citation labels change together. An experiment can evaluate the whole strategy but cannot identify the effect of each individual step.

## Source discrepancies

The script does not change printed totals to match row sums. It currently flags three BSEcE total discrepancies and one missing BSEcE course-row unit value. For example, a printed summer total is 7 while its listed row units sum to 5. Missing units are stated as not printed in that row; they are not filled from another section. Other cross-section differences, including different values for the same course in curriculum/group/description listings, are preserved as separate records.

The page layouts were inspected for the semester assignments, the missing unit, and representative cross-page course boundaries. Automated checks verify every course source span and table-row unit provenance. This is not a claim that multiple independent human reviewers checked every record.

## Reproduce

Use the original canonical filename from this package, `COL-GI-2026-2027_CSE_Only.pdf`.

```bash
pip install pypdf==6.10.0 pdfplumber==0.11.9
python prepare_cse_source.py COL-GI-2026-2027_CSE_Only.pdf reproduced_preprocessed
```

Compare `CSE_Structured_Records.jsonl` SHA-256 with the manifest. Different library versions or an altered PDF may change extraction; retain those as a new preparation version rather than silently mixing records. Ready-to-use records are included, so preprocessing is outside benchmark timings and does not need to run in Colab.

## Evaluation

The fixed test questions, answer key, and scoring rubric stay outside the vector database. The preparation script has no dependency on those files. Use the original PDF to check factual correctness and the actual retrieved prepared records to check source support. Distinguish a useful partial fact from complete prerequisite/code sets. The completed GPU D experiment did not show an overall improvement over the revised-prompt PDF baseline under the prepared quality ratings. Its completeness was 60.4%, compared with 70.8% for that baseline; our group has verified these ratings.
