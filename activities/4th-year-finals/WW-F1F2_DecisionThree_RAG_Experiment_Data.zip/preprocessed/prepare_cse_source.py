"""Reproduce structured CSE source records from the unchanged filtered PDF.

This script reads only the PDF. It does not read questions, answer keys, grades,
or model answers. Page regions and program labels describe the handbook layout.
Run: python prepare_cse_source.py /path/to/CSE.pdf /path/to/output_directory
Dependencies: pypdf==6.10.0, pdfplumber==0.11.9
"""
import argparse, csv, hashlib, json, re
from collections import Counter
from pathlib import Path
import pdfplumber
from pypdf import PdfReader

SCHEMA='DecisionThree-CSE-source-preparation-v1'
PROGRAMS={4:'BSCpE',5:'BSCpE',9:'BSEcE',10:'BSEcE',14:'BSEMC-DAT',15:'BSEMC-DAT',
          17:'BSEMC-GAD',18:'BSEMC-GAD',21:'BSIT',22:'BSIT',25:'BSIT-BA'}
NAMES={'BSCpE':'Bachelor of Science in Computer Engineering',
       'BSEcE':'Bachelor of Science in Electronics Engineering',
       'BSEMC-DAT':'Entertainment and Multimedia Computing with specialization in Digital Animation Technology',
       'BSEMC-GAD':'Entertainment and Multimedia Computing with specialization in Game Development',
       'BSIT':'Bachelor of Science in Information Technology',
       'BSIT-BA':'Bachelor of Science in Information Technology with specialization in Business Analytics'}
# Complete group-requirements regions, including their continuation pages.
GROUPS=[('BSCpE',6,60,7,500),('BSEcE',10,290,12,200),
        ('BSEMC-DAT',15,262,16,610),('BSEMC-GAD',18,299,20,110),
        ('BSIT',22,252,23,480),('BSIT-BA',26,60,27,310)]
YEAR=re.compile(r'^(FIRST|SECOND|THIRD|FOURTH) YEAR$',re.I)
CODE=re.compile(r'^[A-Z]{2,4}$')
NUMBER=re.compile(r'^C\d{3}[A-Z]?$')
def clean(s):return re.sub(r'\s+',' ',s).strip()
def sha(b):return hashlib.sha256(b).hexdigest()

def prepare(pdf_path,out):
    out.mkdir(parents=True,exist_ok=True)
    pdf=pdfplumber.open(pdf_path);reader=PdfReader(pdf_path)
    records=[];issues=[];masks={i:[]for i in range(1,65)}
    def emit(kind,text,pages,**fields):
        record={'record_id':f'CSE-{len(records)+1:04d}','kind':kind,'text':text,
                'source_file':pdf_path.name,'filtered_pdf_pages':sorted(set(pages)),**fields}
        assert text.strip();records.append(record);return record
    def lines(page):return page.extract_text_lines(x_tolerance=1,y_tolerance=2)
    def wordlines(page):
        ws=sorted(page.extract_words(x_tolerance=1,y_tolerance=2),key=lambda w:(w['top'],w['x0']))
        result=[]
        for w in ws:
            match=next((r for r in result[-3:] if abs(r[0]['top']-w['top'])<2),None)
            if match is None:result.append([w])
            else:match.append(w)
        return [sorted(r,key=lambda w:w['x0'])for r in result]
    latest_year={}
    for page_num,program in PROGRAMS.items():
        page=pdf.pages[page_num-1];ls=lines(page);wls=wordlines(page)
        headers=[l for l in ls if re.search(r'First\s+Semester',l['text'],re.I)
                 or re.match(r'^Summer\s+Units',l['text'],re.I)]
        for h in headers:
            prior=[l for l in ls if l['top']<h['top'] and YEAR.match(clean(l['text']))]
            if prior:year=clean(prior[-1]['text']).title();latest_year[program]=year
            else:year=latest_year.get(program)
            if not year:raise ValueError(('Unidentified curriculum year',page_num,h))
            summer=bool(re.match(r'^Summer',h['text'],re.I))
            next_stops=[l['top']for l in ls if l['top']>h['top']+2 and
                (YEAR.match(clean(l['text'])) or re.match(r'^Summer\s+Units',l['text'],re.I)
                 or any(s in l['text']for s in ['GROUP REQUIREMENTS','Electives/Track','*EGR']))]
            stop=min(next_stops,default=730)
            rows=[row for row in wls if h['top']+3<row[0]['top']<stop]
            right_starts=[row[j]['x0']for row in rows for j in range(len(row)-1)
                if CODE.match(row[j]['text']) and NUMBER.match(row[j+1]['text']) and row[j]['x0']>180]
            split=min(right_starts)-.5 if right_starts else 220
            headerwords=[w for w in page.extract_words(x_tolerance=1,y_tolerance=2) if abs(w['top']-h['top'])<2]
            left_unit_x=min(w['x0']for w in headerwords if w['text'].startswith('Units'))
            right_units=[w['x0']for w in headerwords if w['text'].startswith('Units') and w['x0']>split+30]
            unit_x=[left_unit_x,right_units[-1]if right_units else 370]
            semesters=['Summer']if summer else ['First Semester','Second Semester']
            tables=[{'courses':[],'total':None,'source_rows':[],'unassigned_rows':[]}for _ in semesters]
            last_y=h['bottom'];total_y=None
            for row in rows:
                parts=[row]if summer else [[w for w in row if w['x0']<split],[w for w in row if w['x0']>=split]]
                for side,ws in enumerate(parts):
                    if not ws:continue
                    table=tables[side];text=' '.join(w['text']for w in ws)
                    table['source_rows'].append({'text':text,'bbox':[min(w['x0']for w in ws),min(w['top']for w in ws),max(w['x1']for w in ws),max(w['bottom']for w in ws)]})
                    nums=[w for w in ws if re.fullmatch(r'\d+',w['text']) and w['x0']>=unit_x[side]-4]
                    split_code=len(ws)>2 and ws[1]['text']=='C' and re.fullmatch(r'\d{3}[A-Z]?',ws[2]['text'])
                    is_course=len(ws)>1 and CODE.match(ws[0]['text']) and (NUMBER.match(ws[1]['text']) or split_code)
                    if is_course:
                        units=nums[-1]['text']if nums else None
                        code_end=3 if split_code else 2
                        namewords=[w['text']for w in ws[code_end:] if not nums or w is not nums[-1]]
                        table['courses'].append({'code':ws[0]['text']+' '+('C'+ws[2]['text'] if split_code else ws[1]['text']),'name':' '.join(namewords),'units_as_printed':units})
                        if units is None:issues.append({'page':page_num,'issue':'Curriculum row has no identified unit value','text':text})
                    elif nums and all(re.fullmatch(r'\d+',w['text'])for w in ws):
                        table['total']=nums[-1]['text'];total_y=max(total_y or 0,max(w['bottom']for w in ws))
                    elif not nums and table['courses'] and table['total'] is None:
                        table['courses'][-1]['name']+=' '+text
                    else:
                        table['unassigned_rows'].append(text)
                last_y=max(last_y,max(w['bottom']for w in row))
                if all(t['total']is not None for t in tables):break
            if not all(t['courses']and t['total']is not None for t in tables):
                raise ValueError(('Incomplete curriculum parsing',page_num,year,semesters,tables))
            top=min([h['top']]+[prior[-1]['top']]if prior else [h['top']])
            masks[page_num].append((top,last_y+1))
            for sem,table in zip(semesters,tables):
                label=f'{program} ({NAMES[program]}). Curriculum by year. {year}, {sem}.'
                codes=', '.join(c['code']for c in table['courses'])
                text=f'{label}\nCourse codes listed: {codes}.\nSemester total as printed: {table["total"]} units.'
                if table['unassigned_rows']:text+='\nUnassigned table text, preserved without interpretation: '+' | '.join(table['unassigned_rows'])
                emit('semester_summary',text,[page_num],program=program,year=year,semester=sem,**table)
                numeric_sum=sum(int(c['units_as_printed'])for c in table['courses']if c['units_as_printed']is not None)
                if numeric_sum!=int(table['total']):issues.append({'page':page_num,'program':program,'year':year,'semester':sem,'issue':'Sum of listed row units differs from printed total; both preserved','sum_of_rows':numeric_sum,'printed_total':table['total']})
                for course in table['courses']:
                    emit('curriculum_course',f'{label}\n{course["code"]}: {course["name"]}. Units as printed: {course["units_as_printed"] if course["units_as_printed"] is not None else 'not printed in this row'}.',[page_num],program=program,year=year,semester=sem,**course)

    # Group tables use physical row positions so a number stays with its printed
    # course/category rather than a separate column flattened later in the text.
    for program,first,start,last,end in GROUPS:
        category='Group requirements'
        for num in range(first,last+1):
            low=start if num==first else 60;high=end if num==last else 730
            masks[num].append((low,high))
            for row in wordlines(pdf.pages[num-1]):
                if not(low<=row[0]['top']<=high):continue
                text=' '.join(w['text']for w in row)
                if re.match(r'^(?:\d\.|[a-e]\.)\s',text)or re.match(r'^Core Courses',text):category=text
                nums=[w for w in row if re.fullmatch(r'\d+',w['text'])and w['x0']>280]
                unit=nums[-1]['text']if nums else None
                label=' '.join(w['text']for w in row if not nums or w is not nums[-1])
                payload=f'{program} ({NAMES[program]}). Group requirements for the degree.\nCategory context as printed: {category}.\nRow as printed: {label}'
                if unit is not None:payload+=f' | Units as printed: {unit}'
                emit('group_requirement_row',payload,[num],program=program,category=category,row_as_printed=text,units_as_printed=unit,
                    source_bbox=[min(w['x0']for w in row),min(w['top']for w in row),max(w['x1']for w in row),max(w['bottom']for w in row)])

    # Retain all remaining narrative/leadership/elective content; no question-
    # specific filtering. Physical page headers alone are omitted.
    for num in range(2,28):
        rows=[r for r in wordlines(pdf.pages[num-1]) if r[0]['top']>60 and not any(lo-1<=r[0]['top']<=hi+1 for lo,hi in masks[num])]
        blocks=[]
        for row in rows:
            if not blocks or row[0]['top']-max(w['bottom']for w in blocks[-1][-1])>8:blocks.append([row])
            else:blocks[-1].append(row)
        for block in blocks:
            text='\n'.join(' '.join(w['text']for w in row)for row in block)
            emit('source_narrative',f'CSE general information, filtered PDF page {num}.\n{text}',[num],
                source_bbox=[min(w['x0']for row in block for w in row),block[0][0]['top'],max(w['x1']for row in block for w in row),max(w['bottom']for w in block[-1])])

    # Assemble every course entry before splitting into retrieval chunks. The
    # header detector requires same-line title text, excluding prerequisite
    # continuations that consist only of a code and a period.
    combined='';spans=[]
    for num in range(28,65):
        t=reader.pages[num-1].extract_text()or''
        spans.append((len(combined),len(combined)+len(t),num));combined+=t+'\n'
    heads=list(re.finditer(r'(?m)^[ \t]*(?:EGR|CPE|ECE|ITC|EMC)\s+C\d{3}[A-Z]?\s*\.[ \t]*(?=[A-Za-z(])',combined))
    assert heads and clean(combined[heads[0].start():heads[0].end()]).startswith('EGR C101.')
    for idx,h in enumerate(heads):
        start=h.start();end=heads[idx+1].start()if idx+1<len(heads)else len(combined)
        raw=combined[start:end]
        # Exclude page/department headings from the previous course's body.
        cleaned=re.sub(r'(?m)^Page\s+\d+\s*\n','',raw)
        cleaned=re.sub(r'(?m)^\s*(?:DEPARTMENT OF [A-Z &-]+|COMPUTER STUDIES AND ENGINEERING)\s*\n','',cleaned)
        cleaned=clean(cleaned)
        code=re.match(r'(?:EGR|CPE|ECE|ITC|EMC)\s+C\d{3}[A-Z]?',cleaned).group()
        title=cleaned[:cleaned.find('.',cleaned.find('.')+1)+1]if cleaned.count('.')>=2 else cleaned
        footer=re.search(r'(?i)\b(?:Lecture|Laboratory|Lab|Credit)\s*:',cleaned)
        facts=cleaned[footer.start():]if footer else ''
        body=cleaned[:footer.start()].strip()if footer else cleaned
        segs=[]
        for a,b,num in spans:
            if a<end and b>start:
                lo=max(start,a);hi=min(end,b)
                if hi>lo and clean(combined[lo:hi]):segs.append({'filtered_pdf_page':num,'pypdf_start':lo-a,'pypdf_end':hi-a,'exact_excerpt':combined[lo:hi]})
        dept={'EGR':'Computer Engineering','CPE':'Computer Engineering','ECE':'Electronics Engineering','ITC':'Information Technology','EMC':'Entertainment and Multimedia Computing'}[code.split()[0]]
        text=f'CSE course description. {code}. Department/course-code family: {dept}.\n{title}\n'
        if facts:text+='Units and prerequisite statement as printed: '+facts+'\n'
        text+='Description as printed: '+body
        emit('course_description',text,[s['filtered_pdf_page']for s in segs],code=code,title_as_extracted=title,source_segments=segs,
             units_and_prerequisite_text=facts,description_text=body)
    # Preserve the initial course-section headings as a separate source record.
    prefix=clean(combined[:heads[0].start()])
    emit('source_heading',prefix,[28])
    data=''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in records).encode()
    (out/'CSE_Structured_Records.jsonl').write_bytes(data)
    with (out/'CSE_Structured_Source.txt').open('w')as f:
        for r in records:f.write(f"[{r['record_id']}; {r['kind']}; filtered PDF pages {','.join(map(str,r['filtered_pdf_pages']))}]\n{r['text']}\n\n")
    with (out/'Curriculum_Rows.csv').open('w',newline='',encoding='utf-8-sig')as f:
        fields=['record_id','program','year','semester','code','name','units_as_printed','filtered_pdf_pages'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in records:
            if r['kind']=='curriculum_course':w.writerow({k:r[k]for k in fields})
    with (out/'Semester_Totals.csv').open('w',newline='',encoding='utf-8-sig')as f:
        fields=['record_id','program','year','semester','printed_total','sum_of_rows','filtered_pdf_page'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in records:
            if r['kind']=='semester_summary':w.writerow(dict(record_id=r['record_id'],program=r['program'],year=r['year'],semester=r['semester'],printed_total=r['total'],sum_of_rows=sum(int(c['units_as_printed'])for c in r['courses']if c['units_as_printed']is not None),filtered_pdf_page=r['filtered_pdf_pages'][0]))
    normalized=[clean(p.extract_text()or'')for p in reader.pages]
    manifest={'schema':SCHEMA,'source_file':pdf_path.name,'source_pdf_sha256':sha(pdf_path.read_bytes()),
        'source_text_sha256':sha(json.dumps(normalized,ensure_ascii=False,separators=(',',':')).encode()),
        'source_page_count':len(reader.pages),'records_sha256':sha(data),'record_count':len(records),
        'record_kinds':dict(Counter(r['kind']for r in records)),
        'dependencies':{'pypdf':'6.10.0','pdfplumber':pdfplumber.__version__},
        'method':'Full CSE source: layout-based semester rows and totals; physical group-table rows; retained remaining narratives; whole course entries joined across pages with their verbatim footer attributes placed before the description. Course-code families are labels, not claims of exclusive program applicability.',
        'scope':'All 64 filtered PDF pages; page 1 has no searchable text. No questions, answer key, grades, or generated model answers are read by this preparation script.',
        'limitations':'Group-table row fragments and source inconsistencies are preserved rather than guessed or repaired. Printed semester totals are not replaced by computed sums. Retrieval still uses the same recursive splitter with D=800/200/3, but document boundaries/content ordering change as part of this combined preparation strategy.',
        'issues':issues}
    (out/'Preprocessing_Manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps({k:manifest[k]for k in ['record_count','record_kinds','records_sha256','issues']},indent=2))
    return records,manifest

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('pdf',type=Path);parser.add_argument('output',type=Path);args=parser.parse_args();prepare(args.pdf,args.output)
