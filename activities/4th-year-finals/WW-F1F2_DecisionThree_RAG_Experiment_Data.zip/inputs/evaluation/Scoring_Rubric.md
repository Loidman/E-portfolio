# WW1–WW2 answer and retrieval scoring rubric

This rubric applies to the fixed 12-question CSE set, on both CPU and GPU, for every configuration and measured repetition. It is an evaluation guide, not a chatbot prompt. The completed results are recorded separately in the notebook outputs, trial files, and Excel workbook.

## 1. Preserve the evidence used by the model

For each response, retain the question ID, configuration, device, repetition, answer text, ranked retrieved chunks, source references, and the actual evidence included in the final generation prompt. If the prompt budget shortens or omits a chunk, record that change. Retrieved evidence and evidence actually passed to the language model may differ.

Judge answer correctness against the verified handbook and answer key. Judge source support against the evidence actually given to the model. A statement can be correct according to the handbook but unsupported by the model's supplied evidence.

## 2. Score each response on three separate criteria

| Criterion | Score | Rule |
|---|---:|---|
| Answer correctness | 2 | All substantive factual claims made in the answer agree with the approved source. A correct but incomplete answer can receive 2 here; missing facts lower completeness instead. |
| Answer correctness | 1 | At least one required fact is correct, but the answer also contains an incorrect or unverifiable substantive claim. |
| Answer correctness | 0 | No required fact is correctly answered, the response answers a different question, or it refuses an answerable question without supplying a required fact. |
| Source support | 2 | Every substantive factual claim is supported by the evidence actually supplied to the model. |
| Source support | 1 | Some substantive claims are supported and others are unsupported, contradicted, or attached to the wrong course/program. |
| Source support | 0 | None of the substantive answer claims is supported, or no substantive answer is given. |
| Answer completeness | 0–1 | Number of correctly stated required answer elements divided by the fixed required-answer-element count for that question. |

These are the study's stated scoring conventions, not claims that the activity requires a particular numerical rubric. Record a short reason for any incorrect, unsupported, or missing content. Keep the three criteria separate in the results workbook and average each criterion over questions and repetitions. Do not select the fastest configuration without examining these components.

There are 32 documentary evidence units and two additional answer qualifications across the question set. Completeness uses the per-question denominator in `required_answer_element_count`, not a denominator based on whichever facts happened to be retrieved. The two qualifications are Q02's unresolved-conflict explanation and Q08's additional-prerequisite explanation. They count toward answer completeness but are not extra source passages or retrieval-evidence units.

A complete prerequisite set or complete requested course-code list counts as one grouped unit. Omitting a member means that unit is incomplete. Partial members can still be described in a scoring note. Clear paraphrases are accepted; verbatim matching is not required. Do not penalize normal spelling or punctuation when PDF extraction inserts spaces inside a word.

## 3. Evaluate retrieval relevance

For each returned chunk, record whether it supplies useful evidence for at least one requested part of the question, using the chunk text and its explicit source/course/program context. A useful partial fact or a necessary heading that can be linked to a returned continuation can be relevant. A shared keyword or similar course number alone is insufficient.

Record the reason and supported fact IDs. If reporting Precision@K, divide the relevant returned chunks by the number returned and state K for that configuration. The notebook must separately flag a run that returns fewer chunks than the configured K rather than silently treating it as a normal run.

If reporting evidence coverage, count the unique documentary evidence units fully supported by the union of the returned passages, divided by the fixed `required_evidence_unit_count`. The full set of prerequisite codes may be assembled across returned passages if their course identity is established. Do not reconstruct missing facts from a source passage that was not retrieved. Repeated evidence does not increase coverage.

The quoted passages in the key establish the reference facts. They do not prohibit a different passage in the same approved handbook from supporting an equivalent fact. Such a passage must identify the right course/program and genuinely contain the fact. Record its actual source location and apply the same criterion to every configuration. Q02 is source-specific: its three different listings must each be retrieved or stated with the correct section identity; two 4-unit occurrences cannot replace the requested 2-unit listing.

## 4. Special cases fixed before measurement

- Q02: preserve the documented 4/2/4 discrepancy. Do not assume which source should be corrected.
- Q05: the internship is Fourth Year, Second Semester, and 9 units. Text extraction flattens the two-column layout. Do not infer internship hours from units.
- Q08: EMC C602 and EMC C602A are different courses. EMC C603 also lists EMC C608, so EMC C602 alone does not satisfy its complete listed prerequisites.
- Q09: ITC C402 is distinct from CPE C402 and EMC C402. Credit units are not internship hours.
- Q10: ITC C402 is in Second Semester for both programs and must not be included in either First Semester code set.
- Q12: ITC C604 begins on filtered PDF page 53 and continues on page 54. Its opening continuation on page 54 belongs to C604, not C605.
- All questions are answerable from the supplied source. This small benchmark does not test out-of-scope refusal behavior or complete coverage of the original research proposal.

## 5. Repeated outputs and independence

Store every measured trial, including errors. Warm-up measurements stay separate from scored/timed trials. Do not assume that repeated CPU/GPU outputs are identical.

When the question, answer, and actual supplied context are exactly identical, an earlier quality judgment can be reused if the record names the original judgment and verifies those identical fields. Keep a separate measurement row for every trial. A reused judgment is not a new independent human review.

Automatic checks can verify source hashes, page offsets, IDs, missing fields and arithmetic. They cannot by themselves establish semantic correctness or source support. Do not mark answers manually reviewed unless that review actually occurred.

## 6. Freeze the protocol

The 12-question set is v1.0. Use the same wording, reference answers and rubric for the compared measured runs. If the pilot reveals an ambiguous question or answer-key error, revise the set before final measurement, increment its version, and rerun all compared configurations under that version. Keep reference answers and this rubric outside the vector database and generation prompts.
