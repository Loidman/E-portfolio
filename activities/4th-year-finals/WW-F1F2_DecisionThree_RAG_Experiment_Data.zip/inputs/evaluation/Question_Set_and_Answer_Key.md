# CSE test questions and verified answer key

Prepared for DecisionThree’s WW1–WW2 optimization and CPU/GPU experiment. The 12 questions are answerable from the filtered General Information SY 2026–2027 PDF. They include two questions per primary program/specialization, with four questions at each difficulty level.

Page references below distinguish the filtered PDF position, the original 280-page PDF position, and the number printed on the handbook page.

## Question overview

| ID | Primary program / specialization | Difficulty | Question |
|---|---|---|---|
| Q01 | BSCpE | Easy | What does the Bachelor of Science in Computer Engineering (BSCpE) program focus on? |
| Q02 | BSCpE | Difficult | What unit values are listed for Computer Architecture and Organization in the BSCpE year-by-year curriculum, group requirements, and CPE C401 course description? Do these listings agree? |
| Q03 | BSEcE | Easy | How many lecture units are listed for ECE C405, Design Project 1? |
| Q04 | BSEcE | Average | For ECE C401, ECE Elective 1 (Broadcast Production Engineering 1), what prerequisites and lecture, laboratory, and credit units are listed? |
| Q05 | BSEMC-DAT | Easy | In the Digital Animation Technology curriculum, in which year and semester is EMC C402 Internship listed, and how many units does it carry? |
| Q06 | BSEMC-DAT | Average | For EMC C504 Advanced 2D Animation, what prerequisites and lecture, laboratory, and credit units are listed? |
| Q07 | BSEMC-GAD | Easy | What prerequisite is listed for EMC C614 Multi-Player and Network Games? |
| Q08 | BSEMC-GAD | Difficult | What are the complete prerequisite lists for Game Programming 1, 2, and 3 (EMC C602, EMC C603, and EMC C604)? Does passing Game Programming 1 alone satisfy the listed prerequisites for Game Programming 2? |
| Q09 | BSIT | Average | What prerequisites and credit units are listed in the course description for ITC C402 Internship? |
| Q10 | BSIT | Difficult | Compare the course codes and total units listed for the fourth-year first semester of BSIT and BSIT with specialization in Business Analytics. |
| Q11 | BSIT-BA | Average | According to the BSIT Business Analytics program description, which three data competencies does the specialization develop, and what two business purposes can that knowledge serve? |
| Q12 | BSIT-BA | Difficult | How do ITC C604 Data Analysis using Excel and ITC C605 Data Management and Statistical Analysis using R differ in their listed prerequisites and credit units? |

## Reference answers and supporting evidence

These are reference answers, not chatbot outputs. Equivalent wording is accepted when the facts and their course/program identity remain correct. Each grouped prerequisite or course-code set must be complete to cover that evidence unit.

### Q01 — BSCpE — Easy

What does the Bachelor of Science in Computer Engineering (BSCpE) program focus on?

Reference answer: BSCpE covers the design, development, implementation, maintenance and integration of software and hardware components for modern computing systems and computer-controlled equipment.

Required documentary facts:

- Q01-E1: The program concerns software and hardware components, including their design/development and integration.
- Q01-E2: These components serve modern computing systems and computer-controlled equipment.

Sources:

- CPE_PROGRAM: Computer Engineering program description. Filtered PDF page 3; original PDF page 75; printed page 73.

> The Bachelor of Science in Computer Engineering (BSCpE) is a program that embodies the science and technology of design, development, implementation, maintenance, and integration of software and hardware components in modern computing systems and computer-controlled equipment.

Evaluation note: Do not replace the source description with unsupported claims about careers, licensure or admission requirements.

Difficulty rationale: A direct description is available in one short program paragraph.

### Q02 — BSCpE — Difficult

What unit values are listed for Computer Architecture and Organization in the BSCpE year-by-year curriculum, group requirements, and CPE C401 course description? Do these listings agree?

Reference answer: The year-by-year curriculum lists CPE C401 as 4 units, the group-requirements table lists Computer Architecture & Organization as 2 units, and the course description lists 4 credit units. They do not agree (4, 2 and 4). These passages do not establish which listing should be corrected.

Required documentary facts:

- Q02-E1: BSCpE year-by-year curriculum lists CPE C401 as 4 units.
- Q02-E2: BSCpE group requirements list Computer Architecture & Organization as 2 units.
- Q02-E3: CPE C401 course description lists 4 credit units.
- Q02-A1 (answer qualification, not another source passage): State that the listings disagree; do not claim that one is the authoritative correction.

Sources:

- CPE_C401_YEAR: BSCpE year-by-year curriculum: Third Year, Summer. Filtered PDF page 5; original PDF page 77; printed page 75.

> Summer Units EGR C302 Methods of Research 3 CPE C401 Computer Architecture & Org 4 7

- CPE_C401_GROUP: BSCpE group requirements: Professional Courses / Core Courses. Filtered PDF page 6; original PDF page 78; printed page 76.

> Computer Architecture & Organization 2

- CPE_C401_DESC: Computer Engineering course descriptions: CPE C401. Filtered PDF page 35; original PDF page 193; printed page 191.

> CPE C401. Computer Architecture and Organization. This course includes the study of the evolution of computer architecture and the factors influencing the design of hardware and software elements of computer systems. The focus is on the understanding of the design issues; specifically, instruction set ar chitecture and hardware architecture. Lecture:3 units. Laboratory: 1 unit. Credit: 4 units. Prerequisite: CPE C306.

Evaluation note: These are three source-specific units even though two values are equal. A repeated 4-unit occurrence does not replace the 2-unit group-requirements listing.

Difficulty rationale: Requires evidence from three source sections and recognition of an unresolved discrepancy.

### Q03 — BSEcE — Easy

How many lecture units are listed for ECE C405, Design Project 1?

Reference answer: ECE C405, Design Project 1, lists 1 lecture unit.

Required documentary facts:

- Q03-E1: ECE C405 has 1 lecture unit.

Sources:

- ECE_C405_DESC: Electronics Engineering course descriptions: ECE C405. Filtered PDF page 42; original PDF page 200; printed page 198.

> ECE C405. Design Project 1 . This capstone course utilizes the fundamentals of electronics engineering in the design of an electronic system. It includes the synthesis of processes, analysis of process conditions, and the analytic, heuristic, and optimum design of equipment and proc esses. Economic analysis is included to estimate the cost of equipment, capital investment, total product cost, and profitability. Lecture: 1 unit . Credit: 1 unit. Prerequisite: ECE C314, ECE C308, ECE C302.

Evaluation note: Credit units and lecture units are different categories. Do not answer with an inferred laboratory value.

Difficulty rationale: One explicitly labeled fact occurs in a single course description.

### Q04 — BSEcE — Average

For ECE C401, ECE Elective 1 (Broadcast Production Engineering 1), what prerequisites and lecture, laboratory, and credit units are listed?

Reference answer: The prerequisites are ECE C306 and ECE C308. The course lists 3 lecture units, 1 laboratory unit and 4 credit units.

Required documentary facts:

- Q04-E1: Complete prerequisite set: ECE C306 and ECE C308.
- Q04-E2: Lecture units = 3.
- Q04-E3: Laboratory units = 1.
- Q04-E4: Credit units = 4.

Sources:

- ECE_C401_DESC: Electronics Engineering course descriptions: ECE C401. Filtered PDF page 41; original PDF page 199; printed page 197.

> ECE C401. ECE Elective 1 (Broadcast Production Engineering 1). Discusses operation of audio and video equipment including amplifiers, processors, audio/video mixers, distribution amps, TV cameras, microphones, monitors systems integration, studio electro-acoustic and lighting, TV and radio transmitters and propagation, coverage map calculation and frequency analysis, broadcast networking, broadcast ancillary services ( STL’s and satellite links). It also includes CATV technology and DTH. Lecture: 3 units . Laboratory: 1 unit . Credit: 4 units. Prerequisite: ECE C306, ECE C308.

Evaluation note: Keep ECE C401 distinct from CPE C401. Both prerequisite codes are needed for the grouped prerequisite unit.

Difficulty rationale: Combines closely related facts in one course record while keeping unit categories separate.

### Q05 — BSEMC-DAT — Easy

In the Digital Animation Technology curriculum, in which year and semester is EMC C402 Internship listed, and how many units does it carry?

Reference answer: EMC C402 Internship is listed in the fourth year, second semester, with 9 units.

Required documentary facts:

- Q05-E1: In the Digital Animation Technology curriculum, EMC C402 is in Fourth Year, Second Semester.
- Q05-E2: The listed internship carries 9 units.

Sources:

- DAT_YEAR4: BSEMC Digital Animation Technology: Fourth Year curriculum. Filtered PDF page 15; original PDF page 87; printed page 85.

> FOURTH YEAR First Semester Units Second Semester Units EMC C401 EMC Project 2 3 EMC C402 Internship 9 EMC C511 Animation Design & Production 3 EMC C507 DAT Elective 3 3 ITC C204 App Dev’t & Emerging Tech 3 12 9

Source-layout note: The internship row is in the right-hand Second Semester column. Year, semester and 9 units were checked against the page image; linear text alone does not preserve column membership.

- DAT_IDENTITY: Group-requirements heading identifies the Digital Animation specialization. Filtered PDF page 15; original PDF page 87; printed page 85.

> GROUP REQUIREMENTS FOR THE DEGREE OF BACHELOR OF SCIENCE IN ENTERTAINMENT AND MULTIMEDIA COMPUTING WITH SPECIALIZATION IN DIGITAL ANIMATION TECHNOLOGY (BSEMC-DAT)

Evaluation note: Semester follows the physical right-hand column, not the order of linear extracted text. Do not infer internship hours from units.

Difficulty rationale: A direct lookup in one year/semester curriculum table.

### Q06 — BSEMC-DAT — Average

For EMC C504 Advanced 2D Animation, what prerequisites and lecture, laboratory, and credit units are listed?

Reference answer: The prerequisites are EMC C203 and EMC C501. Advanced 2D Animation lists 2 lecture units, 1 laboratory unit and 3 credit units.

Required documentary facts:

- Q06-E1: Complete prerequisite set: EMC C203 and EMC C501.
- Q06-E2: Lecture units = 2.
- Q06-E3: Laboratory units = 1.
- Q06-E4: Credit units = 3.

Sources:

- EMC_C504_DESC: EMC course descriptions: Advanced 2D Animation. Filtered PDF page 60; original PDF page 218; printed page 216.

> EMC C504. Advanced 2D Animation. This course teaches the students the advanced lessons in creating digital 2D animations, analyzing styles and application of different animation techniques. The students will be exposed in projects utilizing storyboards and animatics, and the production of their original 2D animation shorts. This courser will cover a further study of movement in character with emphasis on specific scenes, transitions, and actions. This course promotes understanding and application of the principles of animation and design. Lecture: 2 units. Laboratory: 1 unit. Credit: 3 units. Prerequisite: EMC C203, EMC C501.

Evaluation note: The two prerequisite codes form one complete-set unit; do not confuse this course with Principles of 2D Animation.

Difficulty rationale: Requires several related facts from one identified animation course.

### Q07 — BSEMC-GAD — Easy

What prerequisite is listed for EMC C614 Multi-Player and Network Games?

Reference answer: The listed prerequisite is EMC C603.

Required documentary facts:

- Q07-E1: EMC C614 prerequisite = EMC C603.

Sources:

- EMC_C614_DESC: EMC course descriptions: Multi-Player and Network Games. Filtered PDF page 64; original PDF page 222; printed page 220.

> EMC C614. Multi-Player and Network Games. This course will cover the topics of network games and multiplayer games, from locally hosted network games to online game services. This will cover topics that utilizes cooperative play and competitive multiplayer games. Lecture: 2 units. Laboratory: 1 unit. Credit: 3 units. Prerequisite: EMC C603.

Difficulty rationale: One explicit prerequisite statement answers the question.

### Q08 — BSEMC-GAD — Difficult

What are the complete prerequisite lists for Game Programming 1, 2, and 3 (EMC C602, EMC C603, and EMC C604)? Does passing Game Programming 1 alone satisfy the listed prerequisites for Game Programming 2?

Reference answer: Game Programming 1 (EMC C602) requires EMC C201, EMC C203 and EMC C601. Game Programming 2 (EMC C603) requires EMC C602 and EMC C608. Game Programming 3 (EMC C604) requires EMC C603. Passing Game Programming 1 alone does not satisfy the full listed prerequisite set for Game Programming 2 because EMC C608 is also listed.

Required documentary facts:

- Q08-E1: EMC C602 complete prerequisites: EMC C201, EMC C203 and EMC C601.
- Q08-E2: EMC C603 complete prerequisites: EMC C602 and EMC C608.
- Q08-E3: EMC C604 prerequisite: EMC C603.
- Q08-A1 (answer qualification, not another source passage): Explain that EMC C602 alone is insufficient for EMC C603 because EMC C608 is also listed.

Sources:

- EMC_C602_DESC: EMC course descriptions: Game Programming 1. Filtered PDF page 62; original PDF page 220; printed page 218.

> EMC C602. Game Programming 1. An industry -focused games course, developed in response to relevant industry skill sets and driven by extensive consultation with Game Developers. This course is intended to provide students with basic game programming skills. The course takes students through languages and technologies used heavily by the gaming industry, as well as developing formulas, problem-solving, and practical programming proficiency. Lecture: 2 units. Laboratory: 1 unit. Credit: 3 units. Prerequisite: EMC C201, EMC C203, EMC C601.

- EMC_C603_DESC: EMC course descriptions: Game Programming 2. Filtered PDF page 62; original PDF page 220; printed page 218.

> EMC C603. Game Programming 2 . Designed to introduce students to programming career opportunities in games, entertainment, interactivity, and creative industries. This course covers specific algorithms and technologies used in game development and builds on the students’ core design and programming skills. Students cover more advanced development techniques as well as learning how to develop using industry standard game engines. Lecture: 2 units. Laboratory: 1 unit. Credit: 3 units. Prerequisite: EMC C602, EMC C608.

- EMC_C604_DESC: EMC course descriptions: Game Programming 3. Filtered PDF page 62; original PDF page 220; printed page 218.

> EMC C604. Game Programming 3 . This course will let students work together as teams to design and produce a playable game. This project closely mirrors the real-world production cycle in a game development studio, covering the entire process from pitching the game idea, through writing game design documents, evaluating technical requirements, post processing, managing workload, meeting deadlines, delivering commercial quality artwork and animation, bug-fixing, QA testing and market analysis of the game. Lecture: 2 units. Laboratory: 1 unit. Credit: 3 units. Prerequisite: EMC C603.

Evaluation note: Do not confuse EMC C602 with EMC C602A. Do not add transitive prerequisite claims beyond what the question asks.

Difficulty rationale: Links three similarly named course records and interprets an additional prerequisite.

### Q09 — BSIT — Average

What prerequisites and credit units are listed in the course description for ITC C402 Internship?

Reference answer: ITC C402 Internship lists ITC C508 and ITC C403 as prerequisites and carries 6 credit units.

Required documentary facts:

- Q09-E1: Complete prerequisite set: ITC C508 and ITC C403.
- Q09-E2: ITC C402 carries 6 credit units.

Sources:

- ITC_C402_DESC: IT course descriptions: ITC C402 Internship. Filtered PDF page 49; original PDF page 207; printed page 205.

> ITC C402. Internship. The course prepares the students to elevate their information technology craft, thus encouraging them to develop a higher level of awareness in the study and application of technology. As they are exposed to specific industry partners and deployed in various corporate workplaces, students’ full potential is achieved by helping them realize an individual passion for excellence through collaboration with diverse people and responsible participation as team players both in the industry and in nation-building. Lecture: 6 units. Credit: 6 units. Prerequisite: ITC C508, ITC C403.

Evaluation note: Do not infer training hours from credit units. Keep ITC C402 separate from CPE C402 and EMC C402.

Difficulty rationale: Combines prerequisite and unit information for a named IT course.

### Q10 — BSIT — Difficult

Compare the course codes and total units listed for the fourth-year first semester of BSIT and BSIT with specialization in Business Analytics.

Reference answer: BSIT lists ITC C401, ITC C403, EMC C307 and ITC C508, for a total of 12 units. BSIT with specialization in Business Analytics lists ITC C206, ITC C401, ITC C403, ITC C611 and ITC C612, for a total of 15 units. Each listed first-semester course carries 3 units.

Required documentary facts:

- Q10-E1: BSIT Fourth Year, First Semester complete code set: ITC C401, ITC C403, EMC C307, ITC C508.
- Q10-E2: BSIT Fourth Year, First Semester total = 12 units.
- Q10-E3: BSIT-BA Fourth Year, First Semester complete code set: ITC C206, ITC C401, ITC C403, ITC C611, ITC C612.
- Q10-E4: BSIT-BA Fourth Year, First Semester total = 15 units.

Sources:

- BSIT_YEAR4: BSIT: Fourth Year curriculum. Filtered PDF page 22; original PDF page 94; printed page 92.

> FOURTH YEAR First Semester Units Second Semester Units ITC C401 Sys Admin & Maintenance 3 ITC C402 Internship 6 ITC C403 IT Project 2 3 EMC C307 Foundation of Business Analytics 3 ITC C508 ITE Elective 4 3 12 6

Source-layout note: First-semester course codes and total 12 were checked in the left column of the page image. ITC C402 belongs to the right-hand Second Semester column and is excluded from the requested first-semester list.

- BSIT_IDENTITY: Group-requirements heading identifies the regular BSIT program. Filtered PDF page 22; original PDF page 94; printed page 92.

> GROUP REQUIREMENTS FOR THE DEGREE OF BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY (BSIT) Units Units

- BA_YEAR4: BSIT Business Analytics: Fourth Year curriculum. Filtered PDF page 25; original PDF page 97; printed page 95.

> FOURTH YEAR First Semester Units Second Semester Units ITC C206 Introduction to ERP 3 ITC C402 Internship 6 ITC C401 System Administration & Maintenance 3 ITC C403 IT Project 2 3 ITC C611 Analytics Application 3 ITC C612 Analytics Techniques & Tools 3 15 6

Source-layout note: First-semester codes and total 15 were checked in the left column of the page image. ITC C402 belongs to Second Semester and is excluded from the requested list.

- BA_IDENTITY: BSIT Business Analytics curriculum heading. Filtered PDF page 25; original PDF page 97; printed page 95.

> CURRICULUM REQUIREMENTS BY YEAR FOR THE DEGREE OF BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY WITH SPECIALIZATION IN BUSINESS ANALYTICS

Evaluation note: ITC C402 Internship is in Second Semester for both programs and is not part of either requested code set. Primary coverage is BSIT; the comparison also uses BSIT-BA. Full course titles and each individual 3-unit value are helpful context but not additional required units.

Difficulty rationale: Requires comparison across two program-specific tables and correct semester-column interpretation.

### Q11 — BSIT-BA — Average

According to the BSIT Business Analytics program description, which three data competencies does the specialization develop, and what two business purposes can that knowledge serve?

Reference answer: The specialization develops understanding of data structures, data analysis and data interpretation. The knowledge can support operational optimization and competitive advantage.

Required documentary facts:

- Q11-E1: Competency set: understanding data structures, data analysis and data interpretation.
- Q11-E2: Business-purpose set: operational optimization and competitive advantage.

Sources:

- BA_PROGRAM: Information Technology with Specialization in Business Analytics: program description. Filtered PDF page 23; original PDF page 95; printed page 93.

> INFORMATION TECHNOLOGY WITH SPECIALIZATION IN BUSINESS ANALYTICS PROGRAM This specialization track covers a balance of functional areas, which increases competencies in understanding data structures, data analysis, and data interpretation. The knowledge can be applied to any industry where data can be used for operational optim ization and competitive advantage, which can cater to both local and international industries that demand analytics skills.

Evaluation note: Accept clear paraphrases. Do not require a particular industry, job title or software tool that the paragraph does not specify.

Difficulty rationale: Connects the stated competencies with their uses in one program-description paragraph.

### Q12 — BSIT-BA — Difficult

How do ITC C604 Data Analysis using Excel and ITC C605 Data Management and Statistical Analysis using R differ in their listed prerequisites and credit units?

Reference answer: ITC C604 requires ITC C601 and ITC C603 and carries 3 credit units. ITC C605 requires ITC C604, ITC C602 and ITC C201 and also carries 3 credit units. Their prerequisite sets differ, while their credit units are the same.

Required documentary facts:

- Q12-E1: ITC C604 complete prerequisite set: ITC C601 and ITC C603.
- Q12-E2: ITC C604 credit units = 3.
- Q12-E3: ITC C605 complete prerequisite set: ITC C604, ITC C602 and ITC C201.
- Q12-E4: ITC C605 credit units = 3.

Sources:

- ITC_C604_HEAD: ITC C604 Data Analysis using Excel: heading and opening, continued on next page. Filtered PDF page 53; original PDF page 211; printed page 209.

> ITC C604. Data Analysis using Excel . The use of Excel is widespread in the industry. It is a very powerful data analysis tool , and almost all big and small businesses use Excel in their day -to-day functioning. This course is designed in

- ITC_C604_TAIL: ITC C604 continuation: units and prerequisite clause. Filtered PDF page 54; original PDF page 212; printed page 210.

> keeping in mind two kinds of learners - those who have very little functional knowledge of Excel and those who use Excel regularly but at a peripheral level and wish to enhance their skills. Topics include basic operations such as reading data into Excel using various data formats, organizing and manipulating data, and some of the more advanced functionality of Excel. Lecture: 2 units. Laboratory: 1 unit. Credit: 3 units. Prerequisite: ITC C601, ITC C603

Source-layout note: The page begins with a continuation of ITC C604. Its course identity is established by the heading at the end of filtered page 53. Do not assign this clause to ITC C605, which starts below it.

- ITC_C605_DESC: ITC C605 Data Management and Statistical Analysis using R. Filtered PDF page 54; original PDF page 212; printed page 210.

> ITC C605. Data Management and Statistical Analysis using R. The course is designed to introduce students to the fundamentals of data management using the R programming language, and provides them with fundamental knowledge about data infrastructure and data management technologies that need to be in place before an enterprise can start leveraging business intelligence in their business operations. It also describes various activities focused on creating accurate, consistent, and transparent content with emphasis on data precision, granularity, and meaning, which is necessary for integrating content into business applications and enabling it to be passed along from one business process to another within an enterprise. This course also introduces students to available commands and functions in the RStudio environment that can be used to deploy formalized means of organizing and storing structured and unstructured data in an organization, with opportunities to practice using these tools in a simulated enterprise data management setting in a computer laboratory. Lecture: 2 units. Laboratory: 1 unit. Credit: 3 units. Prerequisite: ITC C604, ITC C602, ITC C201

Evaluation note: The ITC C604 heading is on filtered page 53; its units and prerequisites continue at the top of page 54. Do not attach that opening continuation to ITC C605. The concluding comparison is a paraphrase of the four required facts, not an extra evidence unit.

Difficulty rationale: Requires two course records, and ITC C604 continues across a PDF-page boundary.

## Use during the experiment

Pass only the question text to the chatbot. Do not put this answer key, its evidence excerpts, or the rubric into the vector database or generation prompt. Use the filtered handbook as the searchable source.

Keep the same question IDs, wording, answer key and scoring criteria throughout all measured CPU/GPU trials. If the key changes after a pilot, create a new version and rerun every measured configuration that will be compared.
